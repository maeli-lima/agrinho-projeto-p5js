// Variáveis globais do jogo
let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

let machado;
let folhas = [];

let vidas = 5;
let jogoAtivo = true;

// Missões e pontuação
let missoes = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50]; // Missões aumentadas!
let indiceMissao = 0;
let missaoAtual = missoes[indiceMissao];
let arvoreMissaoContador = 0;
let textoMissao = "Missão: Plante " + missaoAtual + " árvores!";
let mensagemMissao = "";
let pontuacao = 0;

// Tempo da missão (em frames) — 60 frames = 1 segundo
let tempoMissaoMax = 60 * 30; // 30 segundos para cada missão
let tempoMissaoAtual = tempoMissaoMax;

// Novas variáveis para nuvens e animais
let clouds = [];
let animals = [];
const animalEmojis = [
  "🐶",
  "🐱",
  "🐰",
  "🦊",
  "🐻",
  "🐼",
  "🐨",
  "🐯",
  "🐮",
  "🐷",
  "🐸",
  "🐒",
  "🐦",
  "🦉",
  "🐢",
  "🐠",
  "🦋",
  "🐞",
]; // Mais emojis de animais
let lastAnimalSpawnTime = 0;
const animalSpawnInterval = 60 * 5; // Gera um novo animal a cada 5 segundos (300 frames)

// Função setup do p5.js
function setup() {
  let canvas = createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
  machado = new Machado();
  textFont("Arial");
  textAlign(LEFT);

  // Inicializa algumas nuvens
  for (let i = 0; i < 3; i++) {
    clouds.push(new Cloud(random(width), random(height / 4), random(0.5, 1.5)));
  }
}

// Função draw do p5.js (loop principal do jogo)
function draw() {
  if (!jogoAtivo) {
    background(50);
    fill(255);
    textSize(32);
    textAlign(CENTER);
    text("Fim de jogo!", width / 2, height / 2 - 20);
    text("Pontuação final: " + pontuacao, width / 2, height / 2 + 20);
    return;
  }

  // Fundo que muda de cor com a temperatura
  // Cor inicial (baixa temperatura): azul claro
  let corFria = color(180, 220, 250); // Céu claro
  // Cor final (alta temperatura): vermelho/laranja
  let corQuente = color(255, 100, 50); // Céu avermelhado/quente

  // Mapeia a temperatura para um valor entre 0 e 1 para a interpolação de cor
  // Vamos definir um limite de temperatura, por exemplo, de 0 a 50
  let fatorTemperatura = map(temperatura, 0, 50, 0, 1, true); // `true` para limitar os valores
  let corFundo = lerpColor(corFria, corQuente, fatorTemperatura);
  background(corFundo);

  // Atualizar e desenhar nuvens
  for (let i = clouds.length - 1; i >= 0; i--) {
    clouds[i].update();
    clouds[i].display();
    if (clouds[i].isOffscreen()) {
      clouds.splice(i, 1);
      clouds.push(new Cloud(-50, random(height / 4), random(0.5, 1.5))); // Reaparece do lado esquerdo
    }
  }

  mostrarInformacao(); // Exibe informações do jogo na tela

  temperatura += 0.05; // Aumenta a temperatura gradualmente

  jardineiro.mostrar();
  jardineiro.atualizar();

  // Desenha todas as árvores plantadas
  for (let arvore of plantas) {
    arvore.mostrar();
  }

  machado.atualizar();
  machado.cortarArvores();
  machado.exibir();

  // Atualiza e desenha partículas de folhas
  for (let i = folhas.length - 1; i >= 0; i--) {
    folhas[i].atualizar();
    folhas[i].mostrar();
    if (folhas[i].fim()) folhas.splice(i, 1); // Remove folhas que desapareceram
  }

  // Lógica para o tempo da missão e perda de vida
  if (tempoMissaoAtual > 0) {
    tempoMissaoAtual--;
  } else {
    // Tempo esgotado e missão não concluída
    if (arvoreMissaoContador < missaoAtual) {
      vidas--; // Perde uma vida
      mensagemMissao = "Tempo esgotado! Você perdeu 1 vida.";
      tempoMissaoAtual = tempoMissaoMax; // Reinicia o tempo para a próxima tentativa da missão
      arvoreMissaoContador = 0; // Zera o contador de árvores para a missão atual
      // Verifica se as vidas acabaram
      if (vidas <= 0) {
        jogoAtivo = false; // Fim de jogo
      }
    }
  }

  // Lógica para spawn de animais
  if (frameCount - lastAnimalSpawnTime > animalSpawnInterval) {
    animals.push(new Animal(random(animalEmojis)));
    lastAnimalSpawnTime = frameCount;
  }

  // Atualizar e desenhar animais
  for (let i = animals.length - 1; i >= 0; i--) {
    animals[i].update();
    animals[i].display();
    if (animals[i].isOffscreen()) {
      animals.splice(i, 1); // Remove animais que saíram da tela
    }
  }
}

// Função para exibir informações do jogo
function mostrarInformacao() {
  fill(0); // Cor do texto preta
  textSize(16);
  textAlign(LEFT);
  text("Temperatura: " + temperatura.toFixed(2), 10, 30);
  text("Árvores plantadas: " + totalArvores, 10, 50);
  text("Use as setas para mover. Pressione espaço ou 'p' para plantar.", 10, 70);
  text("Vidas: " + "❤️".repeat(vidas), 10, 90); // Exibe corações para as vidas
  text("Pontuação: " + pontuacao, 10, 110);
  text(textoMissao, 10, 130);
  text("Tempo restante: " + Math.ceil(tempoMissaoAtual / 60) + "s", 10, 150);
  if (mensagemMissao) {
    fill(0, 150, 0); // Cor verde para mensagens de missão
    text(mensagemMissao, 10, 170);
  }
}

// Função keyPressed do p5.js (chamada quando uma tecla é pressionada)
function keyPressed() {
  if (!jogoAtivo) return; // Se o jogo não estiver ativo, não faz nada

  if (key === " " || key === "p") {
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
    plantas.push(arvore); // Adiciona uma nova árvore
    totalArvores++;
    temperatura -= 3; // Reduz a temperatura ao plantar
    if (temperatura < 0) temperatura = 0;

    arvoreMissaoContador++;
    mensagemMissao = ""; // Limpa a mensagem anterior

    // Verifica se a missão foi completada
    if (arvoreMissaoContador >= missaoAtual) {
      pontuacao += 100; // Ganha pontos
      mensagemMissao = "Missão concluída! +100 pontos";
      indiceMissao++; // Avança para a próxima missão
      if (indiceMissao < missoes.length) {
        missaoAtual = missoes[indiceMissao];
        textoMissao = "Nova missão: Plante " + missaoAtual + " árvores!";
        arvoreMissaoContador = 0; // Zera o contador para a nova missão
        tempoMissaoAtual = tempoMissaoMax; // Reinicia o tempo para a nova missão
      } else {
        textoMissao = "Todas as missões concluídas!";
        mensagemMissao = "Parabéns!";
        jogoAtivo = false; // Fim de jogo se todas as missões forem concluídas
      }
    }
  }
}

// CLASSES DO JOGO

// Classe Jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = "👨‍🌾";
    this.velocidade = 3;
    this.andando = false;
  }

  atualizar() {
    this.andando = false;
    // Movimentação do jardineiro com as setas
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
      this.andando = true;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
      this.andando = true;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
      this.andando = true;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
      this.andando = true;
    }

    // Limites da tela (mantém o jardineiro dentro da tela)
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  mostrar() {
    textSize(32);
    let offsetY = this.andando ? sin(frameCount * 0.3) * 3 : 0; // Efeito de "andar"
    text(this.emoji, this.x, this.y + offsetY);
  }
}

// Classe Arvore
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = "🌳";
  }

  mostrar() {
    textSize(32);
    let oscilar = sin(frameCount * 0.1 + this.x * 0.01) * 2; // Efeito de oscilação
    text(this.emoji, this.x + oscilar, this.y);
  }
}

// Classe Machado
class Machado {
  constructor() {
    this.x = -100; // Posição inicial fora da tela
    this.y = -100;
    this.alvoY = -100;
    this.aparecerTempo = 0;
    this.duracao = 100; // Duração que o machado fica visível
    this.cortou = false; // Flag para evitar múltiplos cortes por aparição
    this.emoji = "🪓"; // Emoji para o machado
  }

  atualizar() {
    // O machado aparece a cada 5 segundos (300 frames)
    if (frameCount % 300 === 0) {
      this.x = random(50, width - 50); // Posição X aleatória
      this.alvoY = random(50, height - 100); // Posição Y alvo aleatória
      this.y = -150; // Começa acima da tela
      this.aparecerTempo = frameCount;
      this.cortou = false;
    }

    // Move o machado para baixo
    if (this.y < this.alvoY) {
      this.y += 5;
    }

    // Faz o machado desaparecer após a duração
    if (frameCount - this.aparecerTempo > this.duracao) {
      this.x = -100;
      this.y = -100;
    }
  }

  cortarArvores() {
    if (this.x < 0 || this.y < 0 || this.cortou) return; // Se fora da tela ou já cortou, não faz nada

    for (let i = plantas.length - 1; i >= 0; i--) {
      let arvore = plantas[i];
      let d = dist(this.x, this.y, arvore.x, arvore.y);
      if (d < 100) {
        // Se o machado estiver perto de uma árvore
        // Cria partículas de folhas
        for (let j = 0; j < 15; j++) {
          folhas.push(new Folha(arvore.x, arvore.y));
        }
        plantas.splice(i, 1); // Remove a árvore
        totalArvores--;
        temperatura += 2; // Aumenta a temperatura
        this.cortou = true; // Marca que cortou para esta aparição do machado
      }
    }
  }

  exibir() {
    if (this.x > 0 && this.y > 0) {
      // Exibe o machado se estiver na tela
      textSize(48); // Tamanho maior para o emoji do machado
      text(this.emoji, this.x - 24, this.y + 16); // Ajusta a posição para centralizar o emoji
    }
  }
}

// Classe Folha (partículas)
class Folha {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = random(-2, 2); // Velocidade X aleatória
    this.vy = random(-3, -1); // Velocidade Y aleatória (para cima)
    this.alpha = 255; // Transparência inicial
    this.size = random(8, 16); // Tamanho aleatório
    this.cor = color(34, random(100, 180), 34, this.alpha); // Cor verde com transparência
  }

  atualizar() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 4; // Diminui a transparência
    this.cor.setAlpha(this.alpha); // Atualiza a transparência da cor
  }

  mostrar() {
    noStroke();
    fill(this.cor);
    ellipse(this.x, this.y, this.size); // Desenha a folha como um círculo
  }

  fim() {
    return this.alpha <= 0; // Retorna true se a folha desapareceu
  }
}

// Nova Classe Nuvem
class Cloud {
  constructor(x, y, speedMultiplier) {
    this.x = x;
    this.y = y;
    this.emoji = "☁️";
    this.size = random(40, 80); // Tamanho aleatório da nuvem
    this.speed = random(0.2, 0.8) * speedMultiplier; // Velocidade aleatória
  }

  update() {
    this.x += this.speed;
  }

  display() {
    textSize(this.size);
    text(this.emoji, this.x, this.y);
  }

  isOffscreen() {
    return this.x > width + this.size; // Verifica se a nuvem saiu da tela
  }
}

// Nova Classe Animal
class Animal {
  constructor(emoji) {
    this.emoji = emoji;
    this.x = random(width); // Posição X inicial aleatória
    this.y = height - 30; // Posição Y na parte inferior da tela
    this.speed = random(-0.5, 0.5); // Velocidade e direção aleatória (pode ir para esquerda ou direita)
    this.size = 32;
  }

  update() {
    this.x += this.speed;
  }

  display() {
    textSize(this.size);
    text(this.emoji, this.x, this.y);
  }

  isOffscreen() {
    // Considera que saiu da tela se estiver muito para a esquerda ou direita
    return this.x < -50 || this.x > width + 50;
  }
}